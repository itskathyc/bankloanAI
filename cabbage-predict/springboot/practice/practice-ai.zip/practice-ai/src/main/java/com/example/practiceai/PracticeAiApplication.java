package com.example.practiceai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticeAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticeAiApplication.class, args);
	}

}
