package com.mococo.ai_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
