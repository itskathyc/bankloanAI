package com.example.practiceai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticeAiApplicationTests {

	@Test
	void contextLoads() {
	}

}
